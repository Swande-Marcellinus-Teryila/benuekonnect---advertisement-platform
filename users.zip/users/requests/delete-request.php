<?php 
			if(isset($_POST['delete1'])){
			require_once('autoloader.php');

			$check = new Crud();
			$table = $_POST['table'];
			$column_id = $_POST['column_id'];
			$id =$_POST['id'];
		try{	if($check->deleteSpecific($table,$column_id,$id)){
				if(file_exists("../images/product-details/<?=$check->displayField('products','photo','id',$id)?>")){
					unlink("../images/product-details/<?=$check->displayField('products','photo','id',$id)");
				}
				echo '<div class="alert alert-success">Record deleted successfully</div>';
			}
		}catch(Exception $e){
			echo '<div class="alert alert-danger">'.$e->getMessage().'</div>';
		}
		}



?>