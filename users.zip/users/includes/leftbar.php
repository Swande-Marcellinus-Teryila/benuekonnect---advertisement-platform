				<div class="col-sm-3">
					<div class="left-sidebar">
						<h2><i class="fa fa-server"></i> Menu </h2>
						<div class="panel-group category-products" id="accordian"><!--category-productsr-->
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#sportswear">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											<i class=""></i>Products
										</a>
									</h4>
								</div>
								<div id="sportswear" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
											<li><a href="post-product.php">Post Adverts</a></li>
											<li><a href="my-adverts.php">My Adverts</a></li>
											
										</ul>
									</div>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#mens">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											Services
										</a>
									</h4>
								</div>
								<div id="mens" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
											<li><a href="upload-service.php">Upload Services</a></li>
											<li><a href="">My Saved Services</a></li>
											
										</ul>
									</div>
								</div>
							</div>
							
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordian" href="#womens">
											<span class="badge pull-right"><i class="fa fa-plus"></i></span>
											Jobs
										</a>
									</h4>
								</div>
								<div id="womens" class="panel-collapse collapse">
									<div class="panel-body">
										<ul>
											<li><a href="">Post a Job</a></li>
											<li><a href="">View My Saved Jobs</a></li>
											
										</ul>
									</div>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="#"><i class="fa fa-money"></i> Make Payments</a></h4>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="#"><i class="fa fa-envelope"></i> Messages (10)</a></h4>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="../create-account.php?ref=<?=$user['referral_code']?>" target="_blank"><i class="fa fa-link" ></i>Visit</a>
									 <a href=
                                        "whatsapp://send?text=http://localhost/benuekonnect/create-account.php?ref=<?=$user['referral_code']?>"
                                            data-action="share/whatsapp/share"
                                            target="_blank">
                                           <button class="btn btn-success"><i class="fa fa-whatsapp"></i>Share</button>
                                        </a>
                                       

                                        <div class="fb-share-button" data-href="http://localhost/benuekonnect/login.php?referal=&lt;?=$user[&#039;referal_code&#039;]" data-layout="button_count" data-size="small"><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Flocalhost%2Fbenuekonnect%2Flogin.php%3Freferal%3D%253C%253F%253D%2524user%255B%2527referal_code%2527%255D&amp;src=sdkpreparse" class="fb-xfbml-parse-ignore">Share</a></div></h4>
								</div>
							</div>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a href="logout.php"><i class="fa fa-sign-out"></i>Logout</a></h4>
								</div>
							</div>
							
						</div><!--/category-products-->

							<div class="page-header"><!--warning-->
							<h2 class="text text-primary"><i class="fa fa-warning"></i>Warning</h2>						
				<ul class="list-group">
								<li class="list-group-item text-danger">1. Don not buy or sell Without receipt</li>
								<li class="list-group-item text-danger">2. Always meet in a public place to transact don't go 								to home or workplace to transact</li>
								<li class="list-group-item text-danger">3. Do not pay for anything until what you are buying is in your hands</li>
						</ul>
						
						</div><!--/warning-->
						
					
						
					</div>
				</div>
				