<div class="container">
    <div class="row">
        <div class="col-md-12 warning-section">
            <img src="../images/icons/warning.png" class="warningtilted">
              <ol class="text-red">
                <li>Do not buy or sell without receipt</li>
                <li>Always transact with customers in person</li>
                <li>Always meet in a public to transact your business </li>
                <li>Do not go to anyone's home or private workplace to transact business</li>
                <li>Do not pay for anything until what you are paying for is in your hands</li>
                <li>Always be polite to your customers on the phone</li>
                <li>If you notice anything suspicious or fraudulent about any advert or advertiser on this platform, report such to us immediately via email. Thank you</li>
            </ol>
        </div>
    </div>
</div>