<?php 


require('../includes/autoloader.php');
$error = '';
$msg ='';
if(isset($_POST['saveAd'])){
try {
	
	$email = $_POST['email'];
	$password = $_POST['password'];
	$ad_id = $_POST['ad_id'];
	$ad_type =$_POST['ad_type'];
  $auth = new Auth();
  if($auth->is_AuthenticatedUser($email,$password)){
  	$user_id = $auth->displayFieldOr('users','id','email','phone',$email,$email);
  	if($auth->insertSavedAd($user_id,$ad_type,$ad_id)){
  	echo '<script>alert("Ad saved successfully");</script>';
  }else{

  }
}else{
    echo '<script>alert("Invalid Details");</script>';
  }
  
} catch (Exception $e) {
  echo 'echo<script>alert('.$e->getMessage().')</script>';
}
}
