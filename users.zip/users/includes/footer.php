<footer id="footer" style="background-color:#ff00ff; margin-top: 45px;">
	<!--Footer-->
	<div class="footer-top">
		<div class="footer-widget">
			<div class="container" id="footer-container">
				<div class="row">
					<div class="col-sm-4">
						<h2>Service</h2>
						<ul class="nav nav-pills nav-stacked">
							<li><a href="../support.php">Support</a></li>
							<!--li><a href="#">Contact Us</a></li-->
						</ul>
					</div>

					<div class="col-sm-4">
						<h2>Policies</h2>
						<ul class="nav nav-pills nav-stacked">
							<li><a href="../terms.php">Terms of Use</a></li>
							<!--li><a href="#">Privecy Policy</a></li-->
						</ul>
					</div>
					<div class="col-sm-4">
						<h2>About BenueKonnect</h2>
						<ul class="nav nav-pills nav-stacked">
							<li><a href="../aboutus.php">About us</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="footer-bottom">
		<div class="container">
			<div class="row">
				<p class="pull-left">Copyright © 2021 Benuekonnect All rights reserved.</p>
				<p class="pull-right">Designed by <span><a target="_blank" href="https://www.facebook.com/MarcConnect-Technologies-111190170232803/">Marcconnect</a></span></p>
			</div>
		</div>
	</div>

</footer>
<!--/Footer-->



<script src="../js/jquery.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/jquery.scrollUp.min.js"></script>
<script src="../js/price-range.js"></script>
<script src="../js/jquery.prettyPhoto.js"></script>
<script src="../js/main.js"></script>

<script>
	function searchQuery(queryStr) {
		$.post('includes/requests/search.php', {
			searchquery: queryStr
		}, function(data, status) {
			$("#showresults").html(data);
		});

	}
</script>
</body>

</html>