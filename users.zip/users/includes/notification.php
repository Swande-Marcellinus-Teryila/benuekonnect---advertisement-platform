
    <p>
        <span> <img src="../images/icons/notification-icon.png"
         style="width:160px; height:45px; border:blue"></span>
    <div class="product-info" style="border:1px solid blue; padding:8px">

        <p class="text-blue">Share and invite friends to BenueKonnect and get instant N2,000 once hundred (100) of them registers with benuekonnect for free</p>
    </div>
</p>
    