<!--login -->
    
             
      <div  id="myModal"class="modal wow fadeInBig" role="dialog">
        <div class="modal-dialog modal-sm">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title text text-primary">login your Account</h4>
      </div>
      <div class="modal-body"> 
          <div align="center">
            <figure>
              <img src="../images/admin_icon.png" height="150" width="150">
            </figure> 

        <form method="post">
  Email: <br>
<input type="text" name="email">
<br>PASSWORD: <br>
<input type="password" name="password">
<br><br>
<input type="submit" name="login" value="login" class="btn btn-primary btm-lg">
</form>
<div class="modal-footer"><button type="button" class="close" data-dismiss="modal">close</button>  
    
          </div> 
          </div>
          </div>
          </div> 
          </div>
          </div> 
          <!--end of login -->