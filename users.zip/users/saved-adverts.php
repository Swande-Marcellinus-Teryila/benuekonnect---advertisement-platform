  <?php session_start();
         include('../includes/autoloader.php');
    
        $auth = new Auth();
        $auth->checkLogin('user');
        $result = $auth->userInfo('id',$_SESSION['user']);
        foreach($result as $user) { 

         try{$referals = $auth->displayAllSpecificWithOrder('referrals','referral_id',$user['id'],'date_clicked','DESC');}catch(Exception $e){

         }
       
        $total_saved_adverts =  $auth->getTotalSpicific('saved_adverts','postal_id',$user['id']);
		$total_referrals = $auth->getTotalSpicific('referrals','referral_code',
						$user['referral_code']);
		$total_services =  $auth->getTotalSpicific('service_categories','user_id',$user['id']);
        
    
        ?>
     
        
        <!DOCTYPE html>
       <html lang="en">

       <head>
              <meta charset="utf-8">
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <meta name="description" content="">
              <meta name="author" content="">
              <title>My saved Advert | Benuekonnect</title>
              <link href="../css/bootstrap.min.css" rel="stylesheet">
              <link href="../css/font-awesome.min.css" rel="stylesheet">
              <link href="../css/prettyPhoto.css" rel="stylesheet">
              <link href="../css/price-range.css" rel="stylesheet">
              <link href="../css/animate.css" rel="stylesheet">
              <link href="../css/main.css" rel="stylesheet">
              <link href="../css/responsive.css" rel="stylesheet">
              <link href="../css/custom.css" rel="stylesheet">
              <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
              <link rel="shortcut icon" href="images/ico/favicon.ico">
              <link rel="apple-touch-icon-precomposed" sizes="144x144" href="../images/ico/apple-touch-icon-144-precomposed.png">
              <link rel="apple-touch-icon-precomposed" sizes="114x114" href="../images/ico/apple-touch-icon-114-precomposed.png">
              <link rel="apple-touch-icon-precomposed" sizes="72x72" href="../images/ico/apple-touch-icon-72-precomposed.png">
              <link rel="apple-touch-icon-precomposed" href="../images/ico/apple-touch-icon-57-precomposed.png">
       </head>
       <!--/head-->
<?php include('includes/header.php') ?>
    		<section>
		 <table cellpadding="0" border="0" style="width:100%" class="table">
                       <tr>
                              <td style="width:40%">&nbsp;</td>
                              <td style="width:50%"><span class="category-title text-blue">Saved&nbsp;Adverts
                                     </span>
                              </td>
                              <td style="width:10%;" class="msg-logout-icon">
                                     <img src="../images/icons/red-msg.png" class="red-msg-icon">
                                     <br>
                                     <a href="logout.php"><img src="../images/icons/logout section.png" class="logout-icon"></a>
                              </td>
                       </tr>
                </table>
                <table border="0" cellspacing="0" style="width:100%" class="table">
                       <tr>
                              <td style="width:30%">&nbsp;</td>
                              <td style="width:45%">

                                     <img src="profile_picture/<?= $user['photo'] ?>" class="img-circle img-responsive" style="max-height:160px; width: 80%;">
                                     <a href="edit-info.php" class="text-black" style="float:right">

                                            <img src="../images/icons/edit profile section.png" class="edit-profile-icon">
                                     </a><br>
                                     <div class="username"><br>Welcome&nbsp;<span class="username"><?= $user['full_name'] ?>

                                     </div>

                              </td>

                              <td style="width:20%;">&nbsp;

                              </td>
                       </tr>
                </table>
			<div class="container">
				<div class="row">
					<div class="col-md-10"><div class="col-sm-12 mobcat">
					<div class="mob-adverts-users">
						<?php try{

				$latestsaved_adverts = $auth->displayAllSpecificWithOrder2('saved_adverts','user_id','ad_type',$user['id'],'products','date_saved','DESC'); 
                         
					foreach ($latestsaved_adverts as $lsaved_advert) {
echo $prod_id =$lsaved_advert['ad_id'];
                     $savedProducts = $auth->displayAllSpecific('products', 'id',$prod_id);

				 	foreach($savedProducts as $sproduct){



						?>

						<div class="mob-adverts" id="id<?=$idcounter?>">
                     <span class="text-blue"><i class="fa fa-clock-o"></i> <?= $auth->get_time_ago($sproduct['date_uploaded']); ?>
                            <span class="location-icon"><?= $sproduct['location']; ?></span>
                     </span>
                     <table cellspacing="0" border="10px" class="category_table" width="100">
                            <tr>
                                   <td rowspan="3" width="30%"><img src="../images/product-details/<?= $sproduct['photo'] ?>" style="width:100%; height:105px;">
                                   <td style="height: 25px"><?= $sproduct['product_name']; ?></td>
                                   <td style="height: 25px" class="advert_td check-it-btn">
                                          <a href="../product-details.php?prod_id=<?= $sProduct['id'] ?>">
                                                 <img src="../images/icons/check it out.png">
                                          </a>
                                   </td>
                            </tr>
                            <tr>
                                   <td style="height: 25px">N<?= number_format($sproduct['selling_price']); ?></td>
                                   <td style="height: 25px">
                                          <a href="tel:<?= $auth->displayField('users', 'phone', 'id', $sProduct['postal_id']); ?>" style="color:blue">Contact <img src="../images/icons/phone.png" class="img-circle" style="width:16px; height: 18px;"></a>
                                   </td>
                            </tr>
                            <tr>
                              <td style="height: 25px"><?= $sproduct['product_state'] ?></td>
                          
                                                               </tr>
                                                        </table><br>
                                          <?php }}
                                          } catch (Exception $e) {
                                                 echo $e;
                                          } ?>
                                                 </div>
                                          </div>
                                   </div>
                                  

	<script src="../js/custom/my-adverts.js"></script>
		<?php } ?>

	
	