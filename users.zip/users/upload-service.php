        <?php session_start();
        $msg ='';
        $error = '';
         include('../includes/autoloader.php');
try{
        $auth = new Auth();
        $auth->checkLogin('user');
        $result = $auth->userInfo('id',$_SESSION['user']);
        $categories = $auth->displayAll('category');
        if($_SERVER['REQUEST_METHOD']=='POST'){
          $msg=$auth->insertservice($_POST, $_FILES);
           
        }
       }catch(Exception $e){
       	$error= $e->getMessage();
       }
        foreach ($result as $user) { ?>
        <?php include('includes/header.php');?>
    
	<section>
		<div class="container">
			<div class="row">
				<?php include_once('includes/leftbar.php');?>
				<div class="category-tab shop-details-tab"><!--category-tab-->
  
                                            <div class="col-md-12">
                                            	 <?php if($msg){?> <br><br>
                                                            <div class="alert alert-success fa fa-check"> <?=$msg?></div>
                                                        <?php } if($error){?><br><br>
                                                            <div class="alert alert-danger" id="danger_alert"><i class="fa fa-close"></i> <?=$error?></div>
                                                        <?php } ?>
                                                <div class="">
                                                        <h3 class="headings">Upload Services</h3>
                                                    </div>
                                                    <div class="card-block">
                                                        <form class="form-material" method="post" id="addservice" enctype="multipart/form-data">
                                                            <div class="form-group form-success">
                                                                <select class="form-group form-control" id="service_category" required="required" name="service_category_id">
                                                                
                                                                </select>
                                                                
                                                            </div> 
                                                            <div class="form-group form-success">
                                                            	<label class="float-label">Service</label>
                                                                <input type="text" name="service" class="form-control" required="" pl>
                                                                <span class="form-bar"></span>
                                                                
                                                            </div>
                                                            <div class="form-group form-success">
                                                            	 <label class="float-label">Service Description</label>
                                                               <textarea class="form-control" name="description" required="required"></textarea placeholder= "Description">
                                                                <span class="form-bar"></span>
                                                               
                                                            </div>
                                                            
                                                               
                                                               
                                                            </div>
                                                            <div class="form-group form-success">
                                                            	  <label class="float-label">Price(&#x20A6;)</label>
                                                                <input type="number" name="price" class="form-control" required="">
                                                                <span class="form-bar"></span>
                                                              
                                                            </div>
                                                            <div class="form-group form-success">service Photo
                                                                <input type="file" name="photo" class="form-control" required="">
                                                                
                                                            </div>
                                                             <button type="submit" class="btn btn-primary" class="form-control" id="submit"> <i class="fa fa-plus"></i> Add</button>
                                                        
                                                        </form>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        
							</div>	
						</div>
					</div><!--/category-tab-->
					
					
				</div>
			</div>
		</div>
	</section>
	<?php include('includes/footer.php'); ?>
	<script src="../js/custom/addservices.js"></script>
		<?php } ?>

	
	