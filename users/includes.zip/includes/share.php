<div class="container">
    <div class="row">
        <div class="col-md-12 share text-blue"><b>Share</b>  
         <img src="../images/icons/share.png" class="share-icon"> 
         <img src="../images/icons/logo.png" style="width: 80px; height:40px;"> <b>on</b>
            <ul>
                <li><img src="../images/icons/bullet.png" class="custom-bullet">
                 <a href="whatsapp://send?text=Have you held of benuekonnect? 
                 benuekonnect is a free online platform where you can buy and sell anything(services, skills,products etc), you can also get jobs and so much more  on benuekonnect, click the link below to get started. its 100% FREE https://www.benuekonnect.com/create-account.php?ref=<?=$user['referral_code']?>">
                    <img src="../images/icons/whatsapp.png" class="share-icon"> <b>Whatsapp</b>
                </a>
                </li>
                <li>&nbsp;<img src="../images/icons/bullet.png" class="custom-bullet"> </a>
                <img src="../images/icons/twitter.png" class="share-icon"> <b>Twitter</b></li>
                <li>&nbsp;
                    <img src="../images/icons/bullet.png" class="custom-bullet"> 
                    <img src="../images/icons/instagram.png" class="share-icon"> <b>Instagram</b> </li>
                    <li>&nbsp;&nbsp;
 <img src="../images/icons/bullet.png" class="custom-bullet"> &nbsp;
                    <span data-href="https://benuekonnect.com" data-layout="button_count" data-size="large"><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fbenuekonnect.com%2F&amp;src=sdkpreparse" class="fb-xfbml-parse-ignore">
                    <img src="../images/icons/facebook.png" class="share-icon"> <b>Facebook</b></a></span></li>
            </ul>
        </div>
    </div>
</div>