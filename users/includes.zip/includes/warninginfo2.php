<div class="container">
    <div class="row">
        <div class="col-md-12 warning-section">
            <img src="../images/icons/warning.png" class="warningtilted">
              <ol class="text-red">
                       <p>&nbsp;</p>
                <li><p>Do not buy or sell without receipt. </p></li>
                <li><p>Always transact with customers in person.</p></li>
                <li><P>Always meet in a public place to transact your businesses. </p> </li>
                <li><p>Do not go to anyone's home or private workplace to transact business. </p></li>
                <li><p>Do not pay for anything until what you are paying for is in your hands. </li>
                <li><p>Always be polite to your customers on the phone. </p></li>
                <li><p> Always verify the authenticity of every job advert before you contact the individual or company advertising it. </p></li>
                <li><p>Avoid traveling to far places you don't really know, to meet someone you've never met before. </p></li>
               
                <li><p>Always apply caution and due diligence when investing in any online business advertised here. </p></li>
                 <li><p>If you notice anything suspicious or fraudulent about any advert or advertiser on this platform, report such to us immediately via email.</p>

                    <p> Thank you.</p>
                </li>
            </ol>
        </div>
    </div>
</div>