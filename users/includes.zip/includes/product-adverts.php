<?php $limit = 50;
					 		$idcounter=0;
						try { $total_products = $auth->getTotal('products');
							if (isset($_GET['getlm'])) {
								$limit=$_GET['getlm'];
								if($total_products-$limit>50){
									$limit+=50;
								}else{
									$limit+=$total_products%$limit;
								}
							}

							$latestProducts = $auth->displayAllSpecificWithOrderWithLimit2('products', 'status', 'user_approval_status', '1', '1', 'date_uploaded', 'DESC', $limit);
							
							foreach ($latestProducts as $lproduct) {
								$idcounter++;
							
						?>
 							<div class="mob-adverts" id="id<?=$idcounter?>">
 								<span class="text-blue"><i class="fa fa-clock-o"></i> <?= $auth->get_time_ago($lproduct['date_uploaded']); ?>
 									<span class="location-icon"><?= $lproduct['location']; ?></span>
 								</span>
 								<table cellspacing="0" border="10px" class="category_table" width="100">
 									<tr>
 										<td rowspan="3" width="30%"><img src="../images/product-details/<?= $lproduct['photo'] ?>" style="width:100%; height:105px;">
 										<td style="height: 25px"><?= substr($lproduct['product_name'],0,11); ?></td>
 										<td style="height: 25px" class="advert_td check-it-btn">
 											<a href="../product-details.php?prod_id=<?= $lproduct['id'] ?>">
 												<img src="../images/icons/check it out.png">
 											</a>
 										</td>
 									</tr>
 									<tr>
 										<td style="height: 25px">N<?= number_format($lproduct['selling_price']); ?></td>
 										<td style="height: 25px">
 											<a href="tel:<?= $auth->displayField('users', 'phone', 'id', $lproduct['postal_id']); ?>" style="color:blue">Contact <img src="../images/icons/phone.png" class="img-circle" style="width:16px; height: 18px;"></a>
 										</td>
 									</tr>
 									<tr>
 										<td style="height: 25px"><?= $lproduct['product_state'] ?></td>
 										<td style="height: 25px" class="save-ad-btn">
 											<?php if(!isset($_SESSION['user'])){?>
 												<a href="save-ad.php?ad_id=<?=$lproduct['id']?> && ad_type=products">
 												<img src="../images/icons/save this ad.png">
 											</a>
 											<?Php }else{?>

 											<a href="#" onclick="saveAd('<?=$lproduct['id']?>','products','<?php echo $_SESSION['user']; ?>');" >
 												<img src="../images/icons/save this ad.png">
 											</a>
 										<?php }?>
</td>
 									</tr>
 								</table><br>
 						<?php }}catch(Exception $e) {
									echo "No products have been uploaded yet, be the first to <a href='create-account.php' class='btn btn-primary'>Register </a> and upload your products for free";
								} ?>