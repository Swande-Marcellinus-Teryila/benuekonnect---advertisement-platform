<?php 

session_start();
include('../../includes/autoloader.php');
$error = '';
$msg ='';
 $auth = new Auth();

  try {
if(isset($_SESSION['user'])){
  if(isset($_POST['saveAdinsession'])){
$ad_id = $_POST['ad_id'];
$ad_type =$_POST['ad_type'];
$user_id =$_POST['user_id'];
if($auth->insertSavedAd($user_id,$ad_type,$ad_id)){
    echo 'Ad saved successfully';
  }else{
      echo 'something went wrong, Ad not saved';
  }
}

}else{
if(isset($_POST['saveAd'])){

	
	$email = $_POST['email'];
	$password = $_POST['password'];
	$ad_id = $_GET['ad_id'];
	$ad_type =$_GET['ad_type'];
  $refurl = $_POST['httpback'];
 
  if($auth->is_AuthenticatedUser($email,$password)){
  	$user_id = $auth->displayFieldOr('users','id','email','phone',$email,$email);
  	if($auth->insertSavedAd($user_id,$ad_type,$ad_id)){
     $_SESSION['user'] = $user_id;

  	echo '<script>alert("Ad saved successfully");
     window.location.assign("'.$refurl.'");
    </script>
   ';

  }else{
      echo '<script>alert("something went wrong, Ad not saved");</script>';
  }
}else{
    echo '<script>alert("Invalid Details");</script>';
  }
  
}}
} catch (Exception $e) {
  echo 'echo<script>alert('.$e->getMessage().')</script>';
}
