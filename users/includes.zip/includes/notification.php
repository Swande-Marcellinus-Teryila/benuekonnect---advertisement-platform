   <p>
        <span> <img src="../images/icons/notification-icon.png"
         style="width:160px; height:54px; border:blue"></span>
    <div class="product-info" style="border:1px solid blue; padding:8px">

        <p class="text-blue">We are currently on promo and so, all adverts are free!!!. Whether Products, Services, Jobs Search, Vacancies or Skills advert, it's all FREE.</p>
    </div>
</p>
    