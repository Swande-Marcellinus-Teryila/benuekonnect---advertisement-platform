						<div class="col-sm-12">
							<ul class="nav nav-tabs">
								<li class="active"><a href="#products_table" data-toggle="tab"><i class="fa fa-shopping-cart"></i> My Products(<?=$total_products ?>)</a></li>
								<li><a href="#referral_tab" data-toggle="tab"><i class="fa fa-users"></i> My Referrals(<?=$total_referrals?>)</a></li>
							</ul>
						</div>